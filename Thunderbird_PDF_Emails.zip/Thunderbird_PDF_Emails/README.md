Thunderbird PDF Email Add-in for Excel

This project provides VBA macros for Microsoft Excel that allow users to:

1. Export the active sheet as a PDF and open it directly (**PDF Open Only version**)  
2. Export the active sheet as a PDF and automatically open a new email draft in **Mozilla Thunderbird** with the PDF attached (**Thunderbird version**)  

Originally developed to extend Excel’s built-in “Send as PDF” feature to support Thunderbird, this project aims to automate workflow and reduce repetitive steps.

---

## Features

### PDF Open Only
- Export the active sheet to PDF  
- Automatically open the PDF for review  
- Simple, lightweight macro  

### PDF Export + Thunderbird Compose
- Export the active sheet to PDF  
- Open the PDF automatically  
- Launch Thunderbird with a pre-composed email and the PDF attached  
- Supports both 32-bit and 64-bit Thunderbird  
- Basic error handling for missing paths and file conflicts  

---


### Repository Structure
Thunderbird_PDF_Emails/
├── ExportPDFAndSendMailToThunderbird.xlam   ← Main Excel Add-in (must be placed here)
├── src/
│   ├── ExportPDFAndSendMailToThunderbird.bas ← Thunderbird version source code
│   └── ExportPDFAndOpen.bas                  ← PDF open only version source code
├── LICENSE
└── README.md

- `.xlam` → The add-in for practical use. Must remain in the `Thunderbird_PDF_Emails` folder.  
- `src/` → Source code for review or modification.  
- Generated PDF files are saved in the same folder.  

**Important:**  
- The `.xlam` file **must stay inside `Thunderbird_PDF_Emails`**.  
- Otherwise, PDF export and email draft will fail.  

---

## Known Issues / Limitations
- **OneDrive interference:** PDF export may fail or produce corrupted files if Desktop/Documents are synced with OneDrive.  
  - Workaround: Use a local path like `C:\Thunderbird_PDF_Emails`.  
- Outlook version is not yet supported (future plan).  
- Word version is not yet supported (future plan).  

---

## Roadmap / Next Steps
- Add detailed usage manual with screenshots (Excel setup and Thunderbird launch examples)  
- Provide Outlook version  
- Provide Word version  

 **Note:** Detailed documentation and screenshots will be added soon. Please check back for updates.  

---

## License
This project is released under the **MIT License**.  
See [LICENSE](./LICENSE) for details.  

---

## Author
Developed by **T.T.Malay**